<div class="container">
	<h4>About</h4>
	<hr />
	<div>
		<p>Put page content here.</p>
		<?php 
			if(DEVELOPMENT_MODE){ 
		?>
			<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/about.php</i></small>
		<?php 
			} 
		?>
	</div>
</div>